package cryptography;

import java.io.*;
import java.security.*;

public class Cryptography {

    /**
     * @param args the command line arguments
     * @throws java.security.NoSuchAlgorithmException
     * @throws java.io.UnsupportedEncodingException
     */
    public static void main(String[] args) throws NoSuchAlgorithmException, IOException {
        System.out.println("\tACADEMICOS: ANDERSON PEREIRA RODRIGUES & TATIANY KEIKO MORI \n\t\t\t\tTRABALHO V\n");
        int Size = 4317513;//26301439;
        int bloco = 1024;
        int sharB = 32;

        FileInputStream fis = new FileInputStream("D:\\GIT\\Seguranca Computacional\\Cryptography\\src\\cryptography\\video05.mp4");
        byte[] data = new byte[Size];
        byte[] text2 = new byte[bloco + sharB];
        int aux2 = 0;
        byte[] blocoShar = new byte[bloco + sharB];
        int nre = 0;

        while (nre != -1) {
            nre = fis.read(data);
        }

        MessageDigest mensage = MessageDigest.getInstance("SHA-256");
        int inicio = Size - (Size % bloco);
        byte[] text = new byte[Size - inicio];
        int cont = 0;
        while (inicio < Size) {
            text[cont] = data[inicio];
            inicio++;
            cont++;
        }
        byte[] hash = mensage.digest(text);

        inicio = Size - ((Size % bloco) + bloco);
        cont = 0;
        while (inicio >= 0) {
            System.arraycopy(data, inicio, blocoShar, 0, bloco);
            System.arraycopy(hash, 0, blocoShar, bloco, sharB);
            while (aux2 < blocoShar.length) {
                text2[cont] = blocoShar[aux2];
                aux2++;
                cont++;
            }
            cont = 0;
            aux2 = 0;

            hash = mensage.digest(text2);
            inicio = inicio - bloco;
        }
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            hexString.append(String.format("%02x", 0xFF & b));
        }

        String senhahex = hexString.toString();
        System.out.println("\t"+senhahex+"\n");
    }
}
